﻿This code is written to perform text classification using Multinomial Naive Bayes classifier. It takes a dataset in csv format containing news articles and their respective categories. The dataset is preprocessed to clean the text and create a term frequency-inverse class frequency (TF-ICF) weighted vector representation of each article. The code then splits the dataset into training and testing sets, trains the classifier on the training set, and predicts the category of the articles in the testing set.
To run this code, the following steps were followed:
Step 1 - Load and preprocess the data
1. Open a python environment: I have used Jupyter notebook.
2. Import the necessary libraries: pandas, string, nltk, numpy and TfidfVectorizer from sklearn.feature_extraction.text.
3. Download the stopwords and wordnet packages from nltk by running the following commands:
import nltk 
nltk.download('stopwords') 
nltk.download('wordnet')
4. Load the dataset by specifying the path to the csv file containing the news articles and their respective categories. For example, if the csv file is located in a folder called 'learn-ai-bbc', you would specify the path as './learn-ai-bbc/BBC News Train.csv'.
5. Remove any unnecessary columns from the dataset. In this case, the 'ArticleId' column is removed.
6. Define a function to clean the text by removing punctuation, converting the text to lowercase, tokenizing the text, removing stop words and stemming the words using PorterStemmer.
7. Apply the clean_text function to the 'Text' column of the dataset to create a cleaned version of the text.
8. Get the unique categories of the news articles in the dataset.
9. Define a function to calculate the TF-ICF score of a term in a given category.
10. Create a TfidfVectorizer object with the TF-ICF weighting scheme.
11. Calculate the TF-ICF scores for each term in each category.
12. Transform the documents into TF-ICF vectors.
Step 2 - Split the dataset into training and testing sets
1. Import the train_test_split function from sklearn.model_selection.
2. Split the TF-ICF vectors and the categories into training and testing sets using the train_test_split function. Specify the test_size and random_state parameters as desired.
Step 3,4 - Train the classifier and predict the categories
1. Import the MultinomialNB classifier from sklearn.naive_bayes.
2. Create an instance of the MultinomialNB classifier.
3. Fit the classifier to the training set using the fit method.
4. Use the predict method to predict the categories of the articles in the testing set.
5. Import the classification_report function from sklearn.metrics.
6. Print the classification report, which includes precision, recall, f1-score and support for each category.